package example.alarm;

/**
 * Created by foo on 01/12/17.
 */

public class StopwatchFragment extends MyFragment {
    public StopwatchFragment(){
        setName("Bấm Giờ");
    }
}
