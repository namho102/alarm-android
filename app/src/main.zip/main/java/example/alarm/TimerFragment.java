package example.alarm;

/**
 * Created by foo on 01/12/17.
 */

public class TimerFragment extends MyFragment {
    public TimerFragment(){
        setName("Đếm ngược");
    }
}
