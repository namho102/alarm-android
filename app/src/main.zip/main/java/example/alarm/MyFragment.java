package example.alarm;


import android.support.v4.app.Fragment;

/**
 * Created by foo on 01/12/17.
 */

public class MyFragment extends Fragment {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}